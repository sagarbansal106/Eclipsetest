sap.ui.define(
	["sap/ui/core/util/MockServer"],
	function(MockServer){
		var oMockServer;
		return {
			init: function(){
				oMockServer = new MockServer({
					rootUri: "/sap/opu/odata/sap/ZOFT_FRUITS_SRV/"
				});
				
				// MockServer.config({
				// 	autoRespond: true,
				// 	autoRespondAfter: 1000
				// });
				
				var sPath = jQuery.sap.getModulePath("oft.fiori.localService");
				var sMetaPath = sPath + "/metadata.xml";
				oMockServer.simulate(sMetaPath,{
					sMockdataBaseUrl: sPath + "/mockData",
					bGenerateMissingMockData: true
				});
				oMockServer.start();
				
			}	
		};
	}
);
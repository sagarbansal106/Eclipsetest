sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(Controller, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("oft.fiori.controller.View2", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf oft.fiori.view.View2
		 */
		onInit: function() {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(this.herculis, this);
			
		},
		onBack: function(){
			sap.ui.getCore().byId("idApp").to("idView1");
		},
		onItemSelect: function(oEvent){
			var sPath = oEvent.getParameter("listItem").getBindingContextPath();
			var indexSupp = sPath.split("/")[sPath.split("/").length - 1];
			this.oRouter.navTo("detail2",{
				suppId: indexSupp
			});
		},
		onPress: function(){
			sap.m.MessageBox.alert("Button was clicked");
		},
		onHover: function(){
			sap.m.MessageBox.alert("Button was Hovered");
		},
		herculis: function(oEvent){
			//Restore the state of UI by fruitId
			var sPath = oEvent.getParameter("arguments").fruitId;
			//debugger;
			//sPath = "local>/fruits/" + sPath;
			this.getView().bindElement("/" + sPath);
		},
		supplierPopup : null,
		oInp: null,
		onPopupConfirm: function(oEvent){
			var selectedItem = oEvent.getParameter("selectedItem");
			this.oInp.setValue(selectedItem.getLabel());
		},
		
		oSuppPopup: null,
		onFilter: function(){
			
			if(!this.oSuppPopup){
				this.oSuppPopup = new sap.ui.xmlfragment("oft.fiori.fragments.popup", this);
				
				this.getView().addDependent(this.oSuppPopup);
				
				this.oSuppPopup.setTitle("Suppliers");
				
				this.oSuppPopup.bindAggregation("items",{
					path: "/suppliers",
					template: new sap.m.DisplayListItem({
						label: "{name}",
						value: "{city}"
					})
				});
			}
				
			this.oSuppPopup.open();
		},
		
		onRequest: function(oEvent){
			
			//Store the object of the input field on which F4 was press
			this.oInp = oEvent.getSource();
			
			//Step 1: Display a popup cl_gui_alv_grid, set_table_for_first_table
			if(!this.supplierPopup){
				// this.supplierPopup = new sap.m.SelectDialog({
				// 	title: "Supplier Popup",
				// 	confirm: this.onPopupConfirm.bind(this)
				// });	
				this.supplierPopup = new sap.ui.xmlfragment("oft.fiori.fragments.popup", this);
				
				this.supplierPopup.setTitle("Cities");
				//Will now supply the model set at the view level to its children
				this.getView().addDependent(this.supplierPopup);
				
				//this.supplierPopup.setTitle("")
				//Step 2: Values to be populated with aggregation binding
				this.supplierPopup.bindAggregation("items",{
					path: "/cities",
					template: new sap.m.DisplayListItem({
						label: "{cityName}",
						value: "{famousFor}"
					})
				});
				
			}
			//Step 3: Just open same popup once create
			this.supplierPopup.open();
			
		},
		onConfirm: function(anubhav){
			//debugger;
			if(anubhav === "OK"){
				MessageToast.show("Your fruit has been approved successfully");
				this.getView().byId("idApr").setVisible(false);
			}
		},
		onApprove: function(){
			
			MessageBox.confirm("Do you want to approve this fruit",{
				title: "confirmation",
				//[this.functionName, this], as a substitute we use .bind(this) method
				onClose: this.onConfirm.bind(this)
			});
			
		}
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf oft.fiori.view.View2
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf oft.fiori.view.View2
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf oft.fiori.view.View2
		 */
		//	onExit: function() {
		//
		//	}

	});

});
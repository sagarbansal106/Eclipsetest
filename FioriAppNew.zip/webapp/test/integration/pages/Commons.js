sap.ui.define(
	["sap/ui/test/Opa5"],
	function(Opa5){
		return Opa5.extend("oft.fiori.test.integration.pages.Commons",{
				
		});
	}
);
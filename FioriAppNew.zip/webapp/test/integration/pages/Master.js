sap.ui.define([
		"sap/ui/test/Opa5",
		"oft/fiori/test/integration/pages/Commons",
		"sap/ui/test/actions/Press",
		"sap/ui/test/matchers/AggregationFilled",
		"sap/ui/test/matchers/AggregationLengthEquals",
		"sap/ui/test/matchers/PropertyStrictEquals",
		"sap/ui/test/actions/EnterText"
	], function(Opa5, Commons, Press, AggregationFilled, AggregationLengthEquals, PropertyStrictEquals, EnterText) {
		"use strict";

		Opa5.createPageObjects({
			onMasterPage: {
				actions: {
					iSearchValue: function(aActions) {
						return this.waitFor({
							id: "searchFruit",
							viewName: "View1",
							actions: aActions,
							errorMessage: "Able to find the search field on Master page"
						});
					},
					iSearchForFirstObject: function(){
						
						return this.waitFor({
							id: "idFruitsList",
							viewName: "View1",
							matchers: new AggregationFilled({name: "items"}),
							success: function(oList){
								var sTitle = oList.getItems()[0].getTitle();
								return this.iSearchValue(new EnterText({text: sTitle}));
							},
							errorMessage: "List Has no data"
						});
					},
					iClickFirstListItem: function(){
						return this.waitFor({
							id: "idFruitsList",
							viewName: "View1",
							matchers: new AggregationFilled({name: "items"}),
							success: function(oList){
								return this.waitFor({
									id: oList.getItems()[0].getId(),
									action: new Press(),
									errorMessage: "The first list item is not visible to click"
								});
							},
							errorMessage: "List Has no data"
						});
					},
					iClickOnSearchButton: function(){
						return this.waitFor({
							id: "searchFruit",
							viewName: "View1",
							actions: new Press(),
							errorMessage: "Unable to click on search button"
						});
					}
				},
				assertions: {
					iDoSeeListOnScreen  : function() {
						return this.waitFor({
							id: "idFruitsList",
							viewName: "View1",
							success: function() {
								Opa5.assert.ok(true, "List is found on screen");
							},
							errorMessage: "Unable to find list on master page"
						});
					},
					iCheckIfItemHasSameTitle: function(){
						return this.waitFor({
							id: "idFruitsList",
							viewName: "View1",
							matchers: new AggregationFilled({name: "items"}),
							check: function(oList){
								var sTitle = oList.getItems()[0].getTitle,
								EveryItemHasTitle = oList.getItems().every(function(oItem){
									return oItem.getTitle().indexOf(sTitle) !== -1;
								});
								return EveryItemHasTitle;
							},
							success: function() {
								Opa5.assert.ok(true, "List Items has some title");
							},
							errorMessage: "There is no title for list"
						});
					},
					iCheckIfListStillHasItem: function(){
						return this.waitFor({
							id: "idFruitsList",
							viewName: "View1",
							matchers: new AggregationFilled({name: "items"}),
							success: function(oList) {
								var sTitle = oList.getItems()[0].getTitle();
								Opa5.assert.ok(sTitle == "Apple", "search is working");
							},	
						});
					}
				}
			}
		});
	}
);
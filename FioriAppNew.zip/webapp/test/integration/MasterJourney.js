sap.ui.define([
	"sap/ui/test/opaQunit"
], function(opaTest) {
	"use strict";

	QUnit.module("Contains All test for master page");
	
	//Journey 1: Load the app and check if the list is displayed
	opaTest("Check if the list appears on master page", function(Given, When, Then) {
		Given.anubhavLaunchMyApp();

		//When.onMyPageUnderTest.iDoMyAction();

		Then.onMasterPage.iDoSeeListOnScreen();
	});
	
	//Journey 2: Enter Some data on search field, click on search button, check if one item
	//is displayed on screen
	opaTest("Check if the search is working with list search", function(Given, When, Then){
		
		When.onMasterPage.iSearchForFirstObject();
		When.onMasterPage.iClickOnSearchButton();
		
		Then.onMasterPage.iCheckIfListStillHasItem();
		
	});

});
sap.ui.define(
	["sap/ui/test/Opa5",
		"oft/fiori/test/integration/arrangements/arrangement",
		"oft/fiori/test/integration/MasterJourney",
		"oft/fiori/test/integration/MasterJourney",
		"oft/fiori/test/integration/pages/Master"
	],
	function (Opa5, Arrangements) {

		Opa5.extendConfig({
			arrangements: new Arrangements(),
			viewNamespace: "oft.fiori.view.",
			autoWait: true
		}); 

	});
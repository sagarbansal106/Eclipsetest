sap.ui.define(
	["oft/fiori/util/formatter"],
	function(formatter){
		
		QUnit.module("formatter - Currency unit Conversion Test");
		
		function currencyValueTestcase(assert, sValue, expectedNum){
			var convertedValue = formatter.getFormattedNumber(sValue);
			assert.strictEqual(convertedValue, expectedNum, "The test for curr. formatter passed");
		}
		
		QUnit.test("Should round down to a two digit from 3 digit", function(assert){
			currencyValueTestcase.call(this, assert, "3.123", "3.12");
		});
		
		QUnit.test("Should round down to a two digit for negative value", function(assert){
			currencyValueTestcase.call(this, assert, "-5", "-5.00");
		});
		
		QUnit.test("Normal number w/o decimal also converted", function(assert){
			currencyValueTestcase.call(this, assert, "10", "10.00");
		});
		
		QUnit.test("Test for null value must return empty", function(assert){
			currencyValueTestcase.call(this, assert, null, "");
		});
		
		
	}
);